using Newtonsoft.Json;
using System.Collections.ObjectModel;

namespace EasySaveV22
{
    public class Data
    {
        //  Path of the file with all data stored in json
        private static string _path = @"savedata.json";
        
        //  Collection of all saved works
        private static ObservableCollection<Work> _workList = new ObservableCollection<Work>();

        public static ObservableCollection<Work> WorkList
        {
            get { return _workList; }
            set { _workList = value; }
        }
        
        public static string SaveDataFilePath
        {
            get { return _path; }
        }
        
        // Trick to create datafile by avoiding File.Create() problems
        private static void CreateFile()
        {
            using (var sw = new StreamWriter(_path, true));
        }
        
        //  Write in datafile to store data
        public static void SaveData()
        {
            CreateFile();
            var workData = JsonConvert.SerializeObject(WorkList, Formatting.Indented, new JsonSerializerSettings { });
            File.WriteAllText(SaveDataFilePath, workData);
        }

        //  Get data from datafile and store to WorkList
        public static void GetData()
        {
            var workData = File.ReadAllText(SaveDataFilePath);
            var listData = JsonConvert.DeserializeObject<List<Work>>(workData);
            foreach (var w in listData)
                WorkList.Add(w);
        }

        //  Create if not exist or get data if exist
        public static void GetSave()
        {
            if (File.Exists(SaveDataFilePath))
                GetData();
            
            else
                SaveData();
        }
    }
}