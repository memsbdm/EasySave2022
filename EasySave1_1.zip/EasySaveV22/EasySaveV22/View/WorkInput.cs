namespace EasySaveV22;

public class WorkInput
{
    public static void Name()
    {
        Console.WriteLine(Lang.LangText[7]);
    }
    
    public static void Src()
    {
        Console.WriteLine(Lang.LangText[8]);
    }
    
    public static void Dest()
    {
        Console.WriteLine(Lang.LangText[10]);
    }

    public static void Choose()
    {
        Console.WriteLine(Lang.LangText[13]);
    }
    
    public static void PathInputError()
    {
        Console.WriteLine(Lang.LangText[9]);
    }
    
    public static void WorkType()
    {
        Console.WriteLine(Lang.LangText[11]);
    }

    public static void WrongInput()
    {
        Console.WriteLine(Lang.LangText[12]);
    }
}