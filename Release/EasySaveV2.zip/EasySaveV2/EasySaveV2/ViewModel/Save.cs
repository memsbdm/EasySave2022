﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace EasySaveV2
{
    public class Save
    {
        // Create all directories before copying files
        public static void CreateDirectories(ListView lvSaves)
        {
            Work work = (Work)lvSaves.SelectedItem;
            foreach (var dirPath in Directory.GetDirectories(work.SrcPath, "*", SearchOption.AllDirectories))
                Directory.CreateDirectory(dirPath.Replace(work.SrcPath, work.DestPath));
        }

        // Copy a file byte to byte
        public static void CopyFile(string file, string dest)
        {
            var fin = new FileStream(file, FileMode.Open);
            var fout = new FileStream(dest, FileMode.Create);
            var i = 0;
            do
            {
                i = fin.ReadByte();
                if (i != -1)
                    fout.WriteByte((byte)i);
            } while (i != -1);

            fin.Close();
            fout.Close();
        }

        // Copy all files of a work
        public static void CopyFiles(ListView lvSaves)
        {
            Work work = (Work)lvSaves.SelectedItem;
            var srcPath = work.SrcPath;
            var destPath = work.DestPath;
            var complete = work.Type == WorkType.complete;

            work.NbFilesLeftToDo = work.TotalFilesToCopy;
            work.WorkState = WorkState.active;

            var encrypt = Encryption.Encrypt;
            double encryptTime = 0;

            SaveInfo.EncryptionTime = 0;

            // For each files of the directory
            foreach (var file in Directory.GetFiles(srcPath, "*.*", SearchOption.AllDirectories))
            {
                // Dest file
                var dest = file.Replace(srcPath, destPath);
                // If complete save or if file doesn't exists or new version of file then copy it
                if (complete || !File.Exists(dest) || File.GetLastWriteTime(file) > File.GetLastWriteTime(dest))
                {
                    // Watch saveDuration
                    var watch = new Stopwatch();
                    watch.Start();
                    if (encrypt)
                        encryptTime = Encryption.EncryptFile(file, dest);
                    else
                        CopyFile(file, dest);
                    watch.Stop();
                    SaveInfo.Start(work, watch, file, dest);
                    if (encrypt)
                        SaveInfo.EncryptionTime = encryptTime;
                    // Set state to ended when last file is copied
                    if ((int)work.Progression == 100)
                        work.WorkState = WorkState.ended;
                    // Write logs
                    LogClass.WriteLogs(lvSaves);
                }
            }
            //We set Encrypt to false to avoid to encrypt files that we dont want to for next saves
            Encryption.Encrypt = false;

            // Success message
        }
    }
}
