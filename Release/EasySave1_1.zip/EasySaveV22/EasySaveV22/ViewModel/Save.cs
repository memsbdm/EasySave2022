namespace EasySaveV22
{
    public class Save
    {
        public static void CreateDirectories(int workNb)
        {
            var currentWork = Data.WorkList[workNb];
            foreach(var dirPath in Directory.GetDirectories(currentWork.SrcPath, "*", SearchOption.AllDirectories))
                Directory.CreateDirectory(dirPath.Replace(currentWork.SrcPath, currentWork.DestPath));
        }

        public static void CopyFile(string file, string dest)
        {
            var fin = new FileStream(file, FileMode.Open);
            var fout = new FileStream(dest, FileMode.Create);
            var i = 0;
            do
            {
                i = fin.ReadByte();
                if (i != -1)
                    fout.WriteByte((byte) i);
            } while (i != -1);
                    
            fin.Close();
            fout.Close();
        }
        
      
        public static void CopyFiles(int workNb)
        {
            var work = Data.WorkList[workNb];
            var srcPath = work.SrcPath;
            var destPath = work.DestPath;
            var complete = work.Type == WorkType.complete;
            
            work.NbFilesLeftToDo = work.TotalFilesToCopy;
            work.WorkState = WorkState.active;
            
            
            var encrypt = Encryption.EncryptAll(work.Name);
            double encryptTime = 0; 
            var key = "";
            if (encrypt)
                key = Encryption.GetKey();
            SaveInfo.EncryptionTime = 0;
            
            foreach (var file in Directory.GetFiles(srcPath, "*.*", SearchOption.AllDirectories))
            {
                var dest = file.Replace(srcPath, destPath);
                if (complete || !File.Exists(dest) || File.GetLastWriteTime(file) > File.GetLastWriteTime(dest))
                {
                    var watch = new System.Diagnostics.Stopwatch();
                    watch.Start();
                    if (encrypt) 
                        encryptTime = Encryption.EncryptFile(file, dest, key);
                    else
                        CopyFile(file, dest);
                    watch.Stop();
                    SaveInfo.Start(work, watch, file, dest);
                    if (encrypt)
                        SaveInfo.EncryptionTime = encryptTime;
                    if ((int)work.Progression == 100)
                        work.WorkState = WorkState.ended;
                    LogClass.WriteLogs(workNb);
                }
            }
            Console.WriteLine("\n" + Lang.LangText[17] +  work.Name + Lang.LangText[18] + "\n");
        }
    }
}

