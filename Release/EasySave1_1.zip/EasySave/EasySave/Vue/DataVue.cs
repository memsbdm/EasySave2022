﻿namespace EasySave.Vue;
using Model;

public class DataVue
{
    public static void DisplayWorkList()
    {   if(Data.WorkList == null)
            Console.WriteLine("--- Work file is empty. ---");
        else
        {
            for (int i = 0; i < Data.WorkList.Length; i++)
            {
                if(Data.WorkList[i].Name == "")
                    Console.WriteLine("{0}.Empty",i+1);
                else
                    Console.WriteLine("{0}.{1}",i+1,Data.WorkList[i].Name);
            }
        }
    }
}