﻿
using EasySave.Vue;

class Program
{
    static void Main(string[] args)
    {
        Menu.Start();
    }
}