﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace EasySave1
{   
    public class Program
    {
        static void Main(string[] args)
        {

            //Model.SaveDataFile();
            //Console.WriteLine(Model.WorkList[0].Name);
            //Model.WorkList[0].Name = "test";
            //Console.WriteLine(Model.WorkList[0].Name);
            //Model.SaveDataFile();
            //Console.WriteLine(Model.WorkList[0].Name);
            //Model.WorkList[0].Name = "";
            //Console.WriteLine(Model.WorkList[0].Name);
            //Model.ReadDataList();
            //Console.WriteLine(Model.WorkList[0].Name);
            //Console.WriteLine("Finished");
            //Model.DisplayWorkList();
            //Model.WorkList[0].Name = "test";
            //Model.GetSave();
            //Model.DisplayWorkList();
            Vue.Start();
        }
    }

}