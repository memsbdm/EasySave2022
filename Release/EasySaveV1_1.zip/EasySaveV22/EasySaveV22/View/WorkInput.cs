namespace EasySaveV22;

public class WorkInput
{
    public static void Name()
    {
        Console.WriteLine("Enter the work name :");
    }
    
    public static void Src()
    {
        Console.WriteLine("Enter the source path :");
    }
    
    public static void Dest()
    {
        Console.WriteLine("Enter the destination path :");
    }

    public static void Choose()
    {
        Console.WriteLine("Choose a work :");
    }
    
    public static void PathInputError()
    {
        Console.WriteLine("This path is not valid, please try again :");
    }
    
    public static void WorkType()
    {
        Console.WriteLine("Choose a save type : complete or differential (c/d)");
    }

    public static void WrongInput()
    {
        Console.WriteLine("Wrong input, please enter again :");
    }
}