﻿namespace EasySave_2
{
    public class Work
    {

        public string Name { get; set; }
        public string SrcPath { get; set; }
        public string DestPath { get; set; }
        public string CreationTime { get; set; }
        public WorkState WorkState { get; set; }
        public WorkType Type { get; set; }
        public int NbFilesLeftToDo { get; set; }
        public double Progression { get; set; }


        //[JsonIgnore]
        public int TotalFilesToCopy { get; set; }
        // [JsonIgnore]
        public long TotalDirSize { get; set; }

        public Work(string _name, string _srcPath, string _destPath, WorkType _type)
        {
            Name = _name;
            SrcPath = _srcPath;
            DestPath = _destPath;
            CreationTime = "";
            WorkState = WorkState.undefined;
            Type = _type;
            TotalFilesToCopy = 0;
            TotalDirSize = 0;

        }
    }

    public enum WorkType
    {
        undefined,
        complete,
        differential
    }

    public enum WorkState
    {
        undefined,
        inactive,
        active,
        ended
    }
}
