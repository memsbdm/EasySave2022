﻿using System;
using System.IO;

using System.Windows;


namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour AddWork.xaml
    /// </summary>
    public partial class AddWork : Window
    {
        WorkType workType;
        public AddWork()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (Complete.IsChecked == true)
            {
                workType = WorkType.complete;
            }
            else
            {
                workType=WorkType.differential;
            }

            if (Directory.Exists(SrcPath.Text))
            {
                if (!Directory.Exists(DestPath.Text))
                    Directory.CreateDirectory(DestPath.Text);

                Work work = new Work(WorkName.Text, SrcPath.Text, DestPath.Text, workType);
                work.CreationTime = DateTime.Now.ToString();
                work.WorkState = WorkState.inactive;
                work.TotalFilesToCopy = SaveAction.FilesToCopy(new DirectoryInfo(work.SrcPath));
                work.TotalDirSize = SaveAction.DirectorySize(new DirectoryInfo(work.SrcPath));

                Model.WorkList.Add(work);

                Model.SaveDataFile();
                MessageBox.Show("Work Saved");
                this.Close();
                App.Current.MainWindow.Show();
            }
            else
            {
                MessageBox.Show("This path is not valid");
            }

        }

        private void GetBackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }
    }
}
