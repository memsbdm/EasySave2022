using System.IO.Compression;

namespace EasySaveV22
{
    public class Work
    {
        public string Name { get; set; }
        public string SrcPath { get; set; }
        public string DestPath { get; set; }
        public string CreationTime { get; set; }
        public WorkState WorkState { get; set; }
        public WorkType Type { get; set; }
        public int NbFilesLeftToDo { get; set; }
        public double Progression { get; set; }
        public int TotalFilesToCopy { get; set; }
        public long TotalDirSize { get; set; }

        public Work(string _name, string _srcPath, string _destPath, WorkType _type)
        {
            Name = _name;
            SrcPath = _srcPath;
            DestPath = _destPath;
            CreationTime = "";
            WorkState = WorkState.undefined;
            Type = _type;
            TotalFilesToCopy = 0;
            TotalDirSize = 0;
        }
        
        // Set name (not empty)
        private void SetName()
        {
            var name = "";
            WorkInput.Name();
            while (name == "")
                name = Console.ReadLine()!;
            Name = name;
        }
        
        // Verify if source directory exists
        private void SetSrc()
        {
            WorkInput.Src();
            var path = Console.ReadLine()!;
            while (!Directory.Exists(path))
            {
                WorkInput.PathInputError();
                path = Console.ReadLine()!;
            }
            SrcPath = path;
        }
    
        // Check if directory exists or create it
        private void SetDest()
        {
            WorkInput.Dest();
            var path = Console.ReadLine()!;
            try
            {
                while ((!Directory.Exists(path)))
                    Directory.CreateDirectory(path);
            }
            catch (Exception e)
            {
                WorkInput.PathInputError();
                path = Console.ReadLine()!;
            }
            DestPath = path;
        }
    
        // Set save type (complete or differential)
        private void SetType()
        {
            WorkInput.WorkType();
            var input = Console.ReadLine()!;
            while (input != "c" && input != "d")
            {
                WorkInput.WrongInput();
                input = Console.ReadLine()!;
            }
            Type = input == "c" ? WorkType.complete : WorkType.differential;
        }

        // Set number of files to copy and total directory size
        private void FilesToCopyAndDirSize()
        {
            foreach (var file in Directory.GetFiles(SrcPath, "*.*", SearchOption.AllDirectories))
            {
                var fileInfo = new FileInfo(file);
                var destFile = file.Replace(SrcPath, DestPath);
                TotalDirSize += fileInfo.Length;
                if (Type == WorkType.complete)
                    TotalFilesToCopy += 1;
                
                else if (!File.Exists(destFile) || (File.GetLastWriteTime(file) != File.GetLastWriteTime(destFile)))
                    TotalFilesToCopy += 1;
            }
        }

        // Add work to worklist and save data file
        public void AddWork()
        {
            SetName();
            SetSrc();
            SetDest();
            SetType();
            CreationTime = DateTime.Now.ToString();
            WorkState = WorkState.inactive;
            FilesToCopyAndDirSize();
            Data.WorkList.Add(this);
            Data.SaveData();
        }
        
    }
    
    public enum WorkType
    {
        undefined,
        complete,
        differential
    }
    public enum WorkState
    {
        undefined,
        inactive,
        active,
        ended
    }
}