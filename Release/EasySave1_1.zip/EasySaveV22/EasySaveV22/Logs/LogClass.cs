using System.Xml;
namespace EasySaveV22
{
    public class LogClass
    {
        public static void WriteLog(int workNb)
        {
            var currentWork = Data.WorkList[workNb];
            var easySaveLogJsonPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveLog.json");
            var logPath = easySaveLogJsonPath.Replace(@"bin\Debug\net6.0", "Logs");
            using (StreamWriter sw = new StreamWriter(logPath, true))
            {
                sw.WriteLine("{");
                sw.WriteLine($"\"Name\": \"{currentWork.Name}\", ");
                sw.WriteLine($"\"FileSource\": \"{SaveInfo.FileSrcPath}\", ");
                sw.WriteLine($"\"FileTarget\": \"{SaveInfo.FileDestPath}\", ");
                sw.WriteLine($"\"FileSize\": {SaveInfo.FileSize}, ");
                sw.WriteLine($"\"FileTransferTime\": {SaveInfo.FileTransferTime} ");
                sw.WriteLine($"\"EncryptionTime\": {SaveInfo.EncryptionTime} ");
                sw.WriteLine($"\"time\": {GetTimestamp(DateTime.Now)} ");
                sw.WriteLine("}");
            }
        }

        public static void WriteLogXML(int workNb)
        {
            var currentWork = Data.WorkList[workNb];
            var easySaveLogXmlPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveLog.xml");
            var logPath = easySaveLogXmlPath.Replace(@"bin\Debug\net6.0", "Logs");
            var settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true
            };

            using (var sw = new StreamWriter(logPath, true))
            {
                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    writer.WriteStartElement("Save");
                    writer.WriteAttributeString("Name", currentWork.Name);
                    writer.WriteElementString("FileSource", SaveInfo.FileSrcPath);
                    writer.WriteElementString("FileTarget", SaveInfo.FileDestPath);
                    writer.WriteElementString("FileSize", XmlConvert.ToString(SaveInfo.FileSize));
                    writer.WriteElementString("FileTransferTime", XmlConvert.ToString(SaveInfo.FileTransferTime));
                    writer.WriteElementString("EncryptionTime", XmlConvert.ToString(SaveInfo.EncryptionTime));
                    writer.WriteElementString("time", GetTimestamp(DateTime.Now));
                    writer.WriteEndElement();
                }
                sw.WriteLine("\n");
            }

        }

        public static void WriteStateLog(int workNb)
        {
            var currentWork = Data.WorkList[workNb];
            var easySaveStateLogJsonPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveStateLog.json");
            var logPath = easySaveStateLogJsonPath.Replace(@"bin\Debug\net6.0", "Logs");
            using (StreamWriter sw = new StreamWriter(logPath, true))
            {
                sw.WriteLine("{");
                sw.WriteLine($"\"Name\": \"{currentWork.Name}\", ");
                sw.WriteLine($"\"SourceDir\": \"{currentWork.SrcPath}\", ");
                sw.WriteLine($"\"TargetDir\": \"{currentWork.DestPath}\", ");
                sw.WriteLine($"\"State\": \"{currentWork.WorkState}\", ");
                sw.WriteLine($"\"TotalFilesToCopy\": {currentWork.TotalFilesToCopy}, ");
                sw.WriteLine($"\"TotalFilesSize\": {currentWork.TotalDirSize}, ");
                sw.WriteLine($"\"NbFilesLeftToDo\": {currentWork.NbFilesLeftToDo} ");
                sw.WriteLine($"\"Progression\": {currentWork.Progression} ");
                sw.WriteLine("}");
            }
        }

        public static void WriteStateLogXML(int workNb)
        {
            var currentWork = Data.WorkList[workNb];
            var easySaveStateLogXmlPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveStateLog.xml");
            var logPath = easySaveStateLogXmlPath.Replace(@"bin\Debug\net6.0", "Logs");
            var settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true
            };
            using (var sw = new StreamWriter(logPath, true))
            {

                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    writer.WriteStartElement("Save");
                    writer.WriteAttributeString("Name", currentWork.Name);
                    writer.WriteElementString("SourceDir", currentWork.SrcPath);
                    writer.WriteElementString("TargetDir", currentWork.DestPath);
                    writer.WriteElementString("State", currentWork.WorkState.ToString());
                    writer.WriteElementString("TotalFilesToCopy", XmlConvert.ToString(currentWork.TotalFilesToCopy));
                    writer.WriteElementString("TotalFilesSize", XmlConvert.ToString(currentWork.TotalDirSize));
                    writer.WriteElementString("NbFilesLeftToDo", XmlConvert.ToString(currentWork.NbFilesLeftToDo));
                    writer.WriteElementString("Progression", XmlConvert.ToString(currentWork.Progression));
                    writer.WriteEndElement();
                }
                sw.WriteLine("\n");
            }

        }

        public static void WriteLogs(int workNb)
        {
            WriteLog(workNb);
            WriteLogXML(workNb);
            WriteStateLog(workNb);
            WriteStateLogXML(workNb);
        }

       

        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("dd/MM/yyyy HH:mm:ss");
        }
    }
}

