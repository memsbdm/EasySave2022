﻿namespace EasySaveV22
{
    class Program
    {
        static void Main(string[] args)
        { 
            Lang.LangPC();
            Menu.Start();
        }
    }
}
