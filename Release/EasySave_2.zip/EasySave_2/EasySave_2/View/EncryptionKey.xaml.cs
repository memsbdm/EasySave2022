﻿using System.Windows;


namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour EncryptionKey.xaml
    /// </summary>
    public partial class EncryptionKey : Window
    {
        public EncryptionKey()
        {
            InitializeComponent();
        }

        private void Validatebtn_Click(object sender, RoutedEventArgs e)
        {
            SaveAction.Key = KeyTxt.Text;
            this.Close();
        }
    }
}
