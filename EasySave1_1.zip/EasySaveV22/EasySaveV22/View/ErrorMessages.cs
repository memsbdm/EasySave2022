namespace EasySaveV22
{
    public class ErrorMessages
    {
        public static void Input()
        {
            Console.WriteLine(Lang.LangText[13]);
        }
        public static void Number()
        {
            Console.WriteLine(Lang.LangText[20]);
        }
    }
}

