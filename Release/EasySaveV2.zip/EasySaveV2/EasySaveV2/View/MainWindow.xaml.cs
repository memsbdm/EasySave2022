﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EasySaveV2.View;

namespace EasySaveV2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static bool _firstLaunch = true;
        public MainWindow()
        {
            InitializeComponent();
            Lang.Fill();
            if (_firstLaunch)
                Data.GetSave();
            _firstLaunch = false;
            CreateBtn.Content = Lang.LangText[0];
            DeleteBtn.Content = Lang.LangText[1];
            SaveOneWorkBtn.Content = Lang.LangText[2];
            SaveAllWorkBtn.Content = Lang.LangText[3];
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {
            AddWork addWork = new AddWork();
            this.Visibility = Visibility.Hidden;
            addWork.Show();
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            DeleteWork deleteWork = new DeleteWork();
            this.Visibility = Visibility.Hidden;
            deleteWork.Show();
        }

        private void SaveOneWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            SaveOneWork saveOneWork = new SaveOneWork();
            this.Visibility = Visibility.Hidden;
            saveOneWork.Show();
        }

        private void SaveAllWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            SaveAllWorks saveAllWorks = new SaveAllWorks();
            this.Visibility = Visibility.Hidden;
            saveAllWorks.Show();
        }

        private void ChangeLang_Click(object sender, RoutedEventArgs e)
        {
            Lang.ChangeLang();
            Application.Current.MainWindow = new MainWindow();
            App.Current.MainWindow.Show();
            this.Close();
            if (ChangeLang.Content == "ENG")
            {
                ChangeLang.Content = "FR";
            }
            else
            {
                ChangeLang.Content = "ENG";
            }
        }
    }
}
