﻿namespace EasySave.Vue;

public class WorkInput
{
    public static void NameInput()
    {
        Console.WriteLine("Enter the work name :");
    }
    
    public static void SrcInput()
    {
        Console.WriteLine("Enter the source path :");
    }
    
    public static void TargetInput()
    {
        Console.WriteLine("Enter the target path :");
    }

    public static void ChooseInput()
    {
        Console.WriteLine("Choose a work :");
    }
    
    public static void PathInputError()
    {
        Console.WriteLine("This path is not valid, please try again :");
    }
    
    public static void WorkTypeInput()
    {
        Console.WriteLine("Choose a save type : complete or differential (c/d)");
    }

    public static void WrongInput()
    {
        Console.WriteLine("Wrong input, please enter again :");
    }
}