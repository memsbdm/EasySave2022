﻿using System.Windows;


namespace EasySave_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreateBtn_Click(object sender, RoutedEventArgs e)
        {
            AddWork addWork = new AddWork();
            this.Visibility = Visibility.Hidden;
            addWork.Show();
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            DeleteWork deleteWork = new DeleteWork();
            this.Visibility = Visibility.Hidden;
            deleteWork.Show();
        }

        private void SaveOneWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            SaveOneWork saveOneWork = new SaveOneWork();
            this.Visibility=Visibility.Hidden;
            saveOneWork.Show();
        }
        
        private void SaveAllWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            SaveAllWorks saveAllWorks = new SaveAllWorks();
            this.Visibility=Visibility.Hidden;
            saveAllWorks.Show();
        }
    }
}
