﻿using EasySaveV2.View;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace EasySaveV2
{
    public class WorkAction
    {
        static List<Thread> threadList = new List<Thread>();
        // Create a new work
        public static void CreateWork(string workName,string srcPath,string destPath,WorkType workType)
        {
            var work = new Work(workName, srcPath, destPath, workType);
            work.CreationTime = DateTime.Now.ToString();
            work.WorkState = WorkState.inactive;
            work.FilesToCopyAndDirSize();
            Data.WorkList.Add(work);
            Data.SaveData();

        }

        // Delete an existing work
        public static void DeleteWork(ListView lvSaves)
        {
            if (lvSaves.SelectedItem != null)
            {
                Data.WorkList.Remove(lvSaves.SelectedItem as Work);
                Data.SaveData();
            }
        }

        // Execute a work
        public static async Task ExecuteOne(int workNb)
        {
                var work = Data.WorkList[workNb];
                Task thread2 = Task.Factory.StartNew(() => JobAppRunning.IsJobAppRunning());
                Task.WaitAll(thread2);
                if (JobAppRunning.IsRunning == false)
                {
                    MessageBoxResult result = MessageBox.Show(Lang.LangText[21], "Confirmation", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        Encryption.Encrypt = true;
                        EncryptionKey encryptionKey = new EncryptionKey();
                        encryptionKey.ShowDialog();
                    }
                    Thread thread = new Thread(work.CopyAll);
                    thread.Start();
                }
                else
                {
                    MessageBox.Show(Lang.LangText[23]);
                }
        }

        // Execute all works with threads
        public static void ExecuteAll()
        {
            threadList.Clear();
            MessageBoxResult result = MessageBox.Show(Lang.LangText[21], "Confirmation", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                Encryption.Encrypt = true;
                EncryptionKey encryptionKey = new EncryptionKey();
                encryptionKey.ShowDialog();
            }

            foreach (var work in Data.WorkList)
            {
                Thread thread = new Thread(work.CopyAll);
                threadList.Add(thread);
            }

            Parallel.Invoke(() =>
            {
                foreach(var thread in threadList)
                {
                    thread.Start();
                }
            });
        }
    }
}
