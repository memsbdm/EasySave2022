namespace EasySaveV22
{
    public class WorkAction
    {
        public static void CreateWork()
        {
            var work = new Work("", "", "", WorkType.undefined);
            work.AddWork();
            Menu.Start();
        }

        public static void DeleteWork()
        {
            var workToDelete = SelectWork.Start();
            Data.WorkList.Remove(Data.WorkList[workToDelete]);
            Data.SaveData();
            Menu.Start();
        }

        public static void ExecuteOne()
        {
            var workToExecute = SelectWork.Start();
            Save.CreateDirectories(workToExecute);
            Save.CopyFiles(workToExecute);
            Menu.Start();
        }
        
        public static void ExecuteAll()
        {
            for (var i = 0; i < Data.WorkList.Count; i++)
            {
                Save.CreateDirectories(i);
                Save.CopyFiles(i);
            }
            Menu.Start();
        }
    }
}