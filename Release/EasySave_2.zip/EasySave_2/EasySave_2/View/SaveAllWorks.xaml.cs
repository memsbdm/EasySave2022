﻿using System.Windows;


namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour SaveAllWorks.xaml
    /// </summary>
    public partial class SaveAllWorks : Window
    {
        public SaveAllWorks()
        {
            InitializeComponent();
            Model.WorkList.Clear();
            Model.ReadDataList();
            lbSaves.ItemsSource = Model.WorkList;
        }

        private void SaveAllWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            if (EncryptionAllChk.IsChecked == true)
            {
                SaveAction.Encrypt = true;
                EncryptionKey encryptionKey = new EncryptionKey();
                encryptionKey.ShowDialog();

            }
            for (int i = 0; i < lbSaves.Items.Count; i++)
            {
                lbSaves.SelectedIndex = i;
                if (lbSaves.SelectedItem != null)
                {
                    SaveAction.CreateDirectories(lbSaves);
                    SaveAction.CopyFiles(lbSaves);
                    MessageBox.Show("Save Completed");
                }
            }
        }

        private void GetBackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }
    }
}
