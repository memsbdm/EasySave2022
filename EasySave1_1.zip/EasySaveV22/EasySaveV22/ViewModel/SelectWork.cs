namespace EasySaveV22
{
    public class SelectWork
    {
        // Return selected work
        public static int Start()
        {
            var selectedWork = -1;
            var input = "";
            var wrongInput = true;
            while (wrongInput)
            {
                try
                {
                    while (selectedWork >= Data.WorkList.Count || selectedWork < 0)
                    {
                        DisplayWorks.Start();
                        input = Console.ReadLine()!;
                        selectedWork = Convert.ToInt32(input);
                    }

                    wrongInput = false;
                }
                catch (Exception)
                {
                    ErrorMessages.Input();
                }
            }
            return selectedWork;
        }
    }
}

