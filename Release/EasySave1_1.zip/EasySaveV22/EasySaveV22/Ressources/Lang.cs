using System.Globalization;
namespace EasySaveV22
{
    public class Lang
    {
        private const string En = @"../../../Ressources/en.txt";
        private const string Fr = @"../../../Ressources/fr.txt";
        public static bool LangEnglish { get; set; }
        public static string[] LangText { get; set; }

        public static void Fill()
        {
            LangText = new string[21];
            var lines = File.ReadLines(LangEnglish ? En : Fr);
            var i = 0;
            foreach (var line in lines)
            { 
                LangText[i] = line;
                i++;
            }
        }

        public static void LangPC()
        {
            if (CultureInfo.CurrentCulture.Name == "fr-FR")
                LangEnglish = false;
            else
                LangEnglish = true;
        }
        public static void ChangeLang()
        {
            LangEnglish = !LangEnglish;
        }
    }
}

