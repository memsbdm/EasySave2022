﻿namespace EasySave.Vue;

public class WorkActionErrors
{
    public static void LimitError()
    {
        Console.WriteLine("Limit of work reached, please delete one first");
    }
    
    public static void EmptyWorkError()
    {
        Console.WriteLine("--- This work is empty ---");
    }
    
    public static void InputError()
    {
        Console.WriteLine("Input not valid");
    }
    
    public static void NumberError()
    {
        Console.WriteLine("Invalid number");
    }
}