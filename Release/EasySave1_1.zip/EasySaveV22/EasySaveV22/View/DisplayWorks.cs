namespace EasySaveV22
{
    public class DisplayWorks
    {
        public static void Start()
        {
            if (Data.WorkList.Count == 0)
            {
                Console.WriteLine(Lang.LangText[19]);
                Menu.Start();
            }
            var i = 0;
            foreach (var work in Data.WorkList)
            {
                Console.WriteLine(i + " - " + work.Name);
                i++;
            }

            Console.WriteLine(Lang.LangText[13]);
        }
    }
}

