namespace EasySaveV22
{
    public class Menu
    {
        private static bool _firstLaunch = true;
        private static string DisplayMenu()
        {
            Console.WriteLine("Choose an option:\n" +
                              "1 - Create a save work\n" +
                              "2 - Delete a save work\n" +
                              "3 - Select a save work to launch\n" +
                              "4 - Launch all save works\n" +
                              "5 - Exit program");
            return Console.ReadLine()!;
        }
        
        public static void Start()
        {
            if (_firstLaunch)
                Data.GetSave();
            _firstLaunch = false;
            while (true)
            {
                switch (DisplayMenu())
                {
                    case "1":
                        WorkAction.CreateWork();
                        break;
                    case "2":
                        WorkAction.DeleteWork();
                        break;
                    case "3":
                        WorkAction.ExecuteOne();
                        break;
                    case "4":
                        WorkAction.ExecuteAll();
                        break;
                    case "5":
                        Environment.Exit(0);
                        break;
                    default:
                        continue;
                }
                break;
            }
        }
    }
}