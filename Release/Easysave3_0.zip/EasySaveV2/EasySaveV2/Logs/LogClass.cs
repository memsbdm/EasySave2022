﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xml;

namespace EasySaveV2
{
    public class LogClass
    {
        // Write Save Log in JSON format
        public static void WriteLog(Work currentWork)
        {
            var easySaveLogJsonPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveLog.json");
            var logPath = easySaveLogJsonPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            using (StreamWriter sw = new StreamWriter(logPath, true))
            {
                sw.WriteLine("{");
                sw.WriteLine($"\"Name\": \"{currentWork.Name}\", ");
                sw.WriteLine($"\"FileSource\": \"{SaveInfo.FileSrcPath}\", ");
                sw.WriteLine($"\"FileTarget\": \"{SaveInfo.FileDestPath}\", ");
                sw.WriteLine($"\"FileSize\": {SaveInfo.FileSize}, ");
                sw.WriteLine($"\"FileTransferTime\": {SaveInfo.FileTransferTime} ");
                sw.WriteLine($"\"EncryptionTime\": {SaveInfo.EncryptionTime} ");
                sw.WriteLine($"\"time\": {GetTimestamp(DateTime.Now)} ");
                sw.WriteLine("}");
            }
        }

        // Write Save Log in XML format
        public static void WriteLogXML(Work currentWork)
        {
            var easySaveLogXmlPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveLog.xml");
            var logPath = easySaveLogXmlPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            var settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true
            };

            using (var sw = new StreamWriter(logPath, true))
            {
                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    writer.WriteStartElement("Save");
                    writer.WriteAttributeString("Name", currentWork.Name);
                    writer.WriteElementString("FileSource", SaveInfo.FileSrcPath);
                    writer.WriteElementString("FileTarget", SaveInfo.FileDestPath);
                    writer.WriteElementString("FileSize", XmlConvert.ToString(SaveInfo.FileSize));
                    writer.WriteElementString("FileTransferTime", XmlConvert.ToString(SaveInfo.FileTransferTime));
                    writer.WriteElementString("EncryptionTime", XmlConvert.ToString(SaveInfo.EncryptionTime));
                    writer.WriteElementString("time", GetTimestamp(DateTime.Now));
                    writer.WriteEndElement();
                }
                sw.WriteLine("\n");
            }

        }

        // Write State Log in JSON format
        public static void WriteStateLog(Work currentWork)
        {
            var easySaveStateLogJsonPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveStateLog.json");
            var logPath = easySaveStateLogJsonPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            using (StreamWriter sw = new StreamWriter(logPath, true))
            {
                sw.WriteLine("{");
                sw.WriteLine($"\"Name\": \"{currentWork.Name}\", ");
                sw.WriteLine($"\"SourceDir\": \"{currentWork.SrcPath}\", ");
                sw.WriteLine($"\"TargetDir\": \"{currentWork.DestPath}\", ");
                sw.WriteLine($"\"State\": \"{currentWork.WorkState}\", ");
                sw.WriteLine($"\"TotalFilesToCopy\": {currentWork.TotalFilesToCopy}, ");
                sw.WriteLine($"\"TotalFilesSize\": {currentWork.TotalDirSize}, ");
                sw.WriteLine($"\"NbFilesLeftToDo\": {currentWork.NbFilesLeftToDo} ");
                sw.WriteLine($"\"Progression\": {currentWork.Progression} ");
                sw.WriteLine("}");
            }
        }

        // Write State Log in XML format
        public static void WriteStateLogXML(Work currentWork)
        {
            var easySaveStateLogXmlPath = Path.Combine(Directory.GetCurrentDirectory(), "EasySaveStateLog.xml");
            var logPath = easySaveStateLogXmlPath.Replace(@"bin\Debug\net6.0-windows", "Logs");
            var settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true
            };
            using (var sw = new StreamWriter(logPath, true))
            {

                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    writer.WriteStartElement("Save");
                    writer.WriteAttributeString("Name", currentWork.Name);
                    writer.WriteElementString("SourceDir", currentWork.SrcPath);
                    writer.WriteElementString("TargetDir", currentWork.DestPath);
                    writer.WriteElementString("State", currentWork.WorkState.ToString());
                    writer.WriteElementString("TotalFilesToCopy", XmlConvert.ToString(currentWork.TotalFilesToCopy));
                    writer.WriteElementString("TotalFilesSize", XmlConvert.ToString(currentWork.TotalDirSize));
                    writer.WriteElementString("NbFilesLeftToDo", XmlConvert.ToString(currentWork.NbFilesLeftToDo));
                    writer.WriteElementString("Progression", XmlConvert.ToString(currentWork.Progression));
                    writer.WriteEndElement();
                }
                sw.WriteLine("\n");
            }

        }

        public static void WriteLogs(Work currentWork)
        {
            WriteLog(currentWork);
            WriteLogXML(currentWork);
            WriteStateLog(currentWork);
            WriteStateLogXML(currentWork);
        }



        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("dd/MM/yyyy HH:mm:ss");
        }
    }
}
