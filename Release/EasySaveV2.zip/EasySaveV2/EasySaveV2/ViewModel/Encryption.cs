﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasySaveV2
{
    public class Encryption
    {
        public static bool Encrypt { get; set; } = false;
        public static string Key { get; set; }


        // Encrypt and copy file
        public static double EncryptFile(string srcPath, string destPath)
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = Path.Combine(Directory.GetCurrentDirectory(), @"CryptoSoft\CryptoSoft\bin\Debug\net6.0\CryptoSoft.exe"),
                Arguments = $"{srcPath} {destPath} {Key}"
            };
            var proc = Process.Start(startInfo);
            proc.WaitForExit();
            return (proc.ExitTime - proc.StartTime).TotalSeconds;
        }
    }
}
