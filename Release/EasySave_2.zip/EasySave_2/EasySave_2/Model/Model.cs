﻿using System.Collections.Generic;
using Newtonsoft.Json;
using System.IO;
using System.Collections.ObjectModel;

namespace EasySave_2
{
    public class Model
    {

        private static string saveDataFilePath = @"savedata.json";

        private static ObservableCollection<Work> workList = new ObservableCollection<Work>();

        public static ObservableCollection<Work> WorkList
        {
            get { return workList; }
            set { workList = value; }
        }

        public static string SaveDataFilePath
        {
            get { return saveDataFilePath; }
        }

        public static void CreateDataFile()
        {
            using (var sw = new StreamWriter(saveDataFilePath, true)) ;
        }

        public static void SaveDataFile()
        {
            CreateDataFile();
            string workData = JsonConvert.SerializeObject(WorkList, Formatting.Indented, new JsonSerializerSettings { });
            File.WriteAllText(SaveDataFilePath, workData);
        }

        public static void ReadDataList()
        {
            string workData = File.ReadAllText(SaveDataFilePath);
            var listData = JsonConvert.DeserializeObject<List<Work>>(workData);
            foreach (Work w in listData)
                WorkList.Add(w);
        }

        public static void GetSave()
        {
            if (File.Exists(SaveDataFilePath))
                ReadDataList();
            
            else
                SaveDataFile();
        }
    }
}
