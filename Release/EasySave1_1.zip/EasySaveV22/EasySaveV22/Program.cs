﻿namespace EasySaveV22
{
    class Program
    {
        static void Main(string[] args)
        { 
            Lang.LangEnglish = true;
            Menu.Start();
        }
    }
}
