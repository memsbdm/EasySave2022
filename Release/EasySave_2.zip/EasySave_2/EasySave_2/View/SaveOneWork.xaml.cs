﻿using System.Windows;


namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour SaveOneWork.xaml
    /// </summary>
    public partial class SaveOneWork : Window
    {
        public SaveOneWork()
        {
            InitializeComponent();
            Model.WorkList.Clear();
            Model.ReadDataList();
            lbSaves.ItemsSource = Model.WorkList;
        }

        private void SaveWorkBtn_Click(object sender, RoutedEventArgs e)
        {
            if (lbSaves.SelectedItem != null)
            {   
                if(EncryptionChk.IsChecked == true)
                {
                    SaveAction.Encrypt = true;
                    EncryptionKey encryptionKey = new EncryptionKey();
                    encryptionKey.ShowDialog();

                }
                SaveAction.CreateDirectories(lbSaves);
                SaveAction.CopyFiles(lbSaves);
                MessageBox.Show("Save Completed");
            }

        }

        private void GetBackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }





    }
}
