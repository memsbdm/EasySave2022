namespace EasySaveV22
{
    public class ErrorMessages
    {
        public static void Input()
        {
            Console.WriteLine("Input not valid");
        }
        public static void Number()
        {
            Console.WriteLine("Invalid number, try again:");
        }
    }
}

