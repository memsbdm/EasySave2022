﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using EasySaveV2;
using EasySaveV2.View;

namespace EasySaveV2
{
    public class Work : INotifyPropertyChanged
    {

        public string Name { get; set; }
        public string SrcPath { get; set; }
        public string DestPath { get; set; }
        public string CreationTime { get; set; }
        public WorkState WorkState { get; set; }
        public WorkType Type { get; set; }
        public int NbFilesLeftToDo { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void Notify([CallerMemberName] string p = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));

        private double _progression;
        public double Progression { get { return _progression; } set { _progression = value; Notify(); } }

        public int TotalFilesToCopy { get; set; }
        public long TotalDirSize { get; set; }

        public static List<string> ExtensionsList = new List<string> { ".cs"};
        private static readonly object padlock = new object(); 
        public Work(string _name, string _srcPath, string _destPath, WorkType _type)
        {
            Name = _name;
            SrcPath = _srcPath;
            DestPath = _destPath;
            CreationTime = "";
            WorkState = WorkState.undefined;
            Type = _type;
            TotalFilesToCopy = 0;
            TotalDirSize = 0;
            CheckName();
        }

        public void CheckName()
        {
            foreach (var work in Data.WorkList)
            {
                if (work.Name == Name || work.SrcPath == SrcPath)
                    Environment.Exit(-1);
                else if (SrcPath == DestPath)
                    Environment.Exit(-2);
            }
        }


        public void FilesToCopyAndDirSize()
        {
            TotalFilesToCopy = 0;
            foreach (var file in Directory.GetFiles(SrcPath, "*.*", SearchOption.AllDirectories))
            {
                var fileInfo = new FileInfo(file);
                var destFile = file.Replace(SrcPath, DestPath);
                TotalDirSize += fileInfo.Length;
                if (Type == WorkType.complete)
                    TotalFilesToCopy += 1;

                else if (!File.Exists(destFile) || ((File.GetLastWriteTime(file) > File.GetLastWriteTime(destFile))))
                    TotalFilesToCopy += 1;
            }
        }

        public void CreateDirectories()
        {
            foreach (var dirPath in Directory.GetDirectories(SrcPath, "*", SearchOption.AllDirectories))
                Directory.CreateDirectory(dirPath.Replace(SrcPath, DestPath));
        }

        // Copy a file byte to byte
        public void CopyFile(string file, string dest)
        {
            var fin = new FileStream(file, FileMode.Open);
            var fout = new FileStream(dest, FileMode.Create);
            var i = 0;
            do
            {
                i = fin.ReadByte();
                if (i != -1)
                    fout.WriteByte((byte)i);
            } while (i != -1);

            fin.Close();
            fout.Close();
        }

        // Copy all files of a work
        public async Task CopyFiles()
        {
            if (!Directory.Exists(DestPath))
                Directory.CreateDirectory(DestPath);
            var complete = Type == WorkType.complete;
            FilesToCopyAndDirSize();

            NbFilesLeftToDo = TotalFilesToCopy;
            WorkState = WorkState.active;
            var encrypt = Encryption.Encrypt;
            double encryptTime = 0;
            SaveInfo.EncryptionTime = 0;

            // For each files of the directory
            foreach (var file in Directory.GetFiles(SrcPath, "*.*", SearchOption.AllDirectories))
            {
                foreach(var extension in ExtensionsList)
                {
                    if (Path.GetExtension(file) == extension)
                    {
                        // Test of priority
                        // MessageBox.Show(Path.GetFileName(file));
                        // Dest file
                        var dest = file.Replace(SrcPath, DestPath);
                        // If complete save or if file doesn't exists or new version of file then copy it
                        if (complete || !File.Exists(dest) || File.GetLastWriteTime(file) > File.GetLastWriteTime(dest))
                        {
                            // Watch saveDuration
                            var watch = new Stopwatch();
                            watch.Start();
                            if (encrypt)
                                encryptTime = await Task.Run(() => Encryption.EncryptFile(file, dest));
                            else
                                await Task.Run(() => CopyFile(file, dest));
                            watch.Stop();
                            SaveInfo.Start(this, watch, file, dest);
                            if (encrypt)
                                SaveInfo.EncryptionTime = encryptTime;
                            // Set state to ended when last file is copied
                            if ((int)Progression == 100)
                            {
                                WorkState = WorkState.ended;
                                MessageBox.Show(Lang.LangText[20]);
                            }
                            // Write logs
                            lock (padlock)
                            {
                                LogClass.WriteLogs(this);
                            }
                            //LogClass.WriteLogs(this);
                        }
                    }   
                }

            }
            foreach (var file in Directory.GetFiles(SrcPath, "*.*", SearchOption.AllDirectories))
            {
                foreach (var extension in ExtensionsList)
                {
                    if (Path.GetExtension(file) != extension)
                    {

                        // Dest file
                        var dest = file.Replace(SrcPath, DestPath);
                        // If complete save or if file doesn't exists or new version of file then copy it
                        if (complete || !File.Exists(dest) || File.GetLastWriteTime(file) > File.GetLastWriteTime(dest))
                        {
                            // Watch saveDuration
                            var watch = new Stopwatch();
                            watch.Start();
                            if (encrypt)
                                encryptTime = await Task.Run(() => Encryption.EncryptFile(file, dest));
                            else
                                await Task.Run(() => CopyFile(file, dest));
                            watch.Stop();
                            SaveInfo.Start(this, watch, file, dest);
                            if (encrypt)
                                SaveInfo.EncryptionTime = encryptTime;
                            // Set state to ended when last file is copied
                            if ((int)Progression == 100)
                            {
                                WorkState = WorkState.ended;
                                MessageBox.Show(Lang.LangText[20]);
                            }
                            // Write logs
                            lock (padlock)
                            {
                                LogClass.WriteLogs(this);
                            }
                        }
                    }
                }

            }
            //We set Encrypt to false to avoid to encrypt files that we dont want to for next saves
            Encryption.Encrypt = false;

            // Success message
        }

        public void CopyAll()
        {
            CreateDirectories();
            CopyFiles();
        }
    }

    public enum WorkType
    {
        undefined,
        complete,
        differential
    }

    public enum WorkState
    {
        undefined,
        inactive,
        active,
        ended
    }
}
