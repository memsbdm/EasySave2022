﻿using System.Windows;


namespace EasySave_2
{
    /// <summary>
    /// Logique d'interaction pour DeleteWork.xaml
    /// </summary>
    public partial class DeleteWork : Window
    {
 
        public DeleteWork()
        {   
            InitializeComponent();
            Model.WorkList.Clear();
			Model.ReadDataList();
			lbSaves.ItemsSource = Model.WorkList;
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            if(lbSaves.SelectedItem != null)
            {
                Model.WorkList.Remove(lbSaves.SelectedItem as Work);
                Model.SaveDataFile();
            }
        }

        private void GetBackBtn_Click(object sender,RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow.Show();
        }

        //private void btnChangeUser_Click(object sender, RoutedEventArgs e)
        //{
        //	if (lbUsers.SelectedItem != null)
        //		(lbUsers.SelectedItem as Work).Name = "Random Name";
        //}

    }

}
