﻿namespace EasySave.Vue;

public class WorkActionSuccess
{ 
    public static void SaveSuccess()
    {
        Console.WriteLine("Save completed successfully.");
    }
    
    public static void DeleteSuccess()
    {
        Console.WriteLine("Save deleted with success");
    }
}