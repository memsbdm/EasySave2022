using System.Diagnostics;
namespace EasySaveV22
{
    public class Encryption
    {
        public static bool EncryptAll(string workName)
        {
            Console.WriteLine(Lang.LangText[14] + workName + Lang.LangText[15]);
            var answer = Console.ReadLine();
            return answer == "y";
        }

        public static string GetKey()
        {
            Console.WriteLine(Lang.LangText[16]);
            var key = Console.ReadLine()!;
            return key;
        }
        
        public static double EncryptFile(string srcPath, string destPath, string key)
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = Path.Combine(Directory.GetCurrentDirectory(), @"CryptoSoft\CryptoSoft\bin\Debug\net6.0\CryptoSoft.exe"),
                Arguments = $"{srcPath} {destPath} {key}"
            };
            var proc = Process.Start(startInfo);
            proc.WaitForExit();
            return (proc.ExitTime - proc.StartTime).TotalSeconds;
        }
    }
}

