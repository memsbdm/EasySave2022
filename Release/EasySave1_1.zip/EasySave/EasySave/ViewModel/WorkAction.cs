﻿namespace EasySave.ViewModel;
using Vue;
using Model;
using Logs;

public class WorkAction
{
    public static long FileTransferTime { get; set; }
    public static string FileSrcPath { get; set; }
    public static string FileDestPath { get; set; }
    public static long FileSize { get; set; }
    
    public static void CreateWork()
    {
        int i = 0;
        while(Data.WorkList[i].WorkState != Work.WorkStateEnum.undefined)
        {
            if(i > 4)
            {
                WorkActionErrors.LimitError();
                Menu.Start();
            }
            else
                i++;
        }
        Data.WorkList[i].SetWorkName();
        Data.WorkList[i].SetWorkSrc();
        Data.WorkList[i].SetWorkTarget();
        Data.WorkList[i].CreationTime = DateTime.Now.ToString();
        Data.WorkList[i].WorkState = Work.WorkStateEnum.inactive;
        Data.WorkList[i].SetWorkType();
        Data.WorkList[i].TotalFilesToCopy = Work.FilesToCopy(new DirectoryInfo(Data.WorkList[i].SrcPath));
        Data.WorkList[i].TotalDirSize = Work.DirectorySize(new DirectoryInfo(Data.WorkList[i].SrcPath));
        Data.SaveDataFile();
        Menu.Start();
    }
    
    public static int ChooseWork()
    {
        WorkInput.ChooseInput();
        DataVue.DisplayWorkList();
        int saveNb = Convert.ToInt32(Console.ReadLine());
        while(saveNb != 1 && saveNb != 2 && saveNb != 3 && saveNb != 4 && saveNb != 5)
        {
            WorkActionErrors.NumberError();
            saveNb = Convert.ToInt32(Console.ReadLine());
        }
        try
        {
            if (Data.WorkList[saveNb - 1].WorkState == Work.WorkStateEnum.undefined)
            {
                WorkActionErrors.EmptyWorkError();
                Menu.Start();
            }
        }
        catch (Exception)
        {
            WorkActionErrors.InputError();
            Menu.Start();
        }
        return saveNb;
    }
    
    public static void DeleteWork()
    {   
        try
        {
            int saveNb = ChooseWork();
            Data.WorkList[saveNb - 1] = new Work("", "", "", Work.WorkType.undefined);
            Data.SaveDataFile();
            WorkActionSuccess.DeleteSuccess();
            Menu.Start();
        }
        catch (Exception)
        {
            WorkActionErrors.InputError();
            Menu.Start();
        }
    }
    
    public static void ExecuteOne()
    {
        int saveNb = ChooseWork();
        Work.GetNbLeftToDo(saveNb);
        CreateDirectories(saveNb);
        CopyFiles(saveNb);
        Menu.Start();
    }
    
    public static void ExecuteAll()
    {
        for(int i = 1; i <= Data.MaxWorksNb; i++)
        {
            Work.GetNbLeftToDo(i);
            if (Data.WorkList[i-1].WorkState != Work.WorkStateEnum.undefined)
            {
                CreateDirectories(i);
                CopyFiles(i);
            }
        }
        Menu.Start();
    }
    
    private static void CreateDirectories(int workNb)
    {
        foreach(var dirPath in Directory.GetDirectories(Data.WorkList[workNb-1].SrcPath, "*", SearchOption.AllDirectories))
            Directory.CreateDirectory(dirPath.Replace(Data.WorkList[workNb-1].SrcPath, Data.WorkList[workNb-1].DestPath));
    }
    
    
    
    
    private static void CopyFiles(int workNb)
        {   
            
            foreach (var filePath in Directory.GetFiles(Data.WorkList[workNb-1].SrcPath, "*.*", SearchOption.AllDirectories))
            {
                var watch = new System.Diagnostics.Stopwatch();
                watch.Start();
                if(Data.WorkList[workNb-1].Type == Work.WorkType.complete)
                {
                    File.Copy(filePath, filePath.Replace(Data.WorkList[workNb-1].SrcPath, Data.WorkList[workNb-1].DestPath), true);
                    Data.WorkList[workNb-1].NbFilesLeftToDo--;
                }
                else
                {
                    if (!File.Exists(filePath.Replace(Data.WorkList[workNb-1].SrcPath, Data.WorkList[workNb - 1].DestPath)))
                    {
                        File.Copy(filePath, filePath.Replace(Data.WorkList[workNb - 1].SrcPath, Data.WorkList[workNb - 1].DestPath), true);
                        Data.WorkList[workNb-1].NbFilesLeftToDo--;
                    }
                    else
                    {
                        if (File.GetLastWriteTime(filePath) != File.GetLastWriteTime(filePath.Replace(Data.WorkList[workNb-1].SrcPath, Data.WorkList[workNb - 1].DestPath)))
                        {
                            File.Copy(filePath, filePath.Replace(Data.WorkList[workNb - 1].SrcPath, Data.WorkList[workNb - 1].DestPath), true);
                            Data.WorkList[workNb-1].NbFilesLeftToDo--;
                        }

                    }
                }
                Data.WorkList[workNb - 1].WorkState = Work.WorkStateEnum.active;
                watch.Stop();
                Work.GetProgression(workNb);
                var fi = new FileInfo(filePath);
                FileTransferTime = watch.ElapsedMilliseconds;
                FileSrcPath = Path.GetFullPath(filePath);
                FileDestPath = Path.GetFullPath(filePath).Replace(Data.WorkList[workNb - 1].SrcPath, Data.WorkList[workNb - 1].DestPath);
                FileSize = fi.Length;
                
                if (Data.WorkList[workNb - 1].NbFilesLeftToDo != 0)
                    Data.WorkList[workNb - 1].WorkState = Work.WorkStateEnum.active;
                
                else
                    Data.WorkList[workNb - 1].WorkState = Work.WorkStateEnum.ended;
                
                LogClass.WriteLogger(workNb);
                LogClass.WriteStateLogger(workNb);

            }
            WorkActionSuccess.SaveSuccess();
        }
}