namespace EasySave1
{
    public class Vue
    {
        private static string DisplayMenu()
        {
            Console.WriteLine("Choose an option:\n" +
                              "1 - Create a save work\n" +
                              "2 - Delete a save work\n" +
                              "3 - Select a save work to launch\n" +
                              "4 - Launch all save works\n" +
                              "5 - Exit program");
            return Console.ReadLine()!;
        }

        public static void Start()
        {
            Model.GetSave();

            while (true)
            {
                switch (DisplayMenu())
                {
                    case "1":
                        SaveAction.CreateWork();
                        break;
                    case "2":
                       SaveAction.DeleteWork();
                        break;
                    case "3":
                       SaveAction.ExecuteOne();
                        break;
                    case "4":
                       SaveAction.ExecuteAll();
                        break;
                    case "5":
                        Environment.Exit(0);
                        break;
                    default:
                        continue;
                }
                break;
            }

        }


        
    }
}