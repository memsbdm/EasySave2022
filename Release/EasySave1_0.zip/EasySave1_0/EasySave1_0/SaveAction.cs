namespace EasySave1
{
    public class SaveAction
    {


        public static long FileTransferTime { get; set; }
        public static string FileSrcPath { get; set; }
        public static string FileDestPath { get; set; }
        public static long FileSize { get; set; }
        
        

        public static void CreateWork()
        {
            int i = 0;
            while(Model.WorkList[i].WorkState != WorkState.undefined)
            {
                if(i > 4)
                {
                    Console.WriteLine("Limit of work reached, please delete one first");
                    Vue.Start();
                }
                else
                {
                    i++;
                }
            }
            Model.WorkList[i].Name = SetWorkName();
            Model.WorkList[i].SrcPath = SetWorkSrc();
            Model.WorkList[i].DestPath = SetWorkTarget();
            Model.WorkList[i].CreationTime = DateTime.Now.ToString();
            Model.WorkList[i].WorkState = WorkState.inactive;
            Model.WorkList[i].Type = SetWorkType();
            Model.WorkList[i].TotalFilesToCopy = FilesToCopy(new DirectoryInfo(Model.WorkList[i].SrcPath));
            Model.WorkList[i].TotalDirSize = DirectorySize(new DirectoryInfo(Model.WorkList[i].SrcPath));
            Model.SaveDataFile();
            Vue.Start();

        }



        public static int ChooseWork()
        {
            Console.WriteLine("Choose a work :");
            Model.DisplayWorkList();
            int saveNb = Convert.ToInt32(Console.ReadLine());
            while(saveNb != 1 && saveNb != 2 && saveNb != 3 && saveNb != 4 && saveNb != 5)
            {
                    Console.WriteLine("Invalid number");
                    saveNb = Convert.ToInt32(Console.ReadLine());
            }
            try
            {

                if (Model.WorkList[saveNb - 1].WorkState == WorkState.undefined)
                {
                    Console.WriteLine("--- This work is empty ---");
                    Vue.Start();

                }
            }
            catch (Exception)
            {
                Console.WriteLine("Input not valid");
                Vue.Start();
            }
            return saveNb;

        }

        public static void DeleteWork()
        {   
            try
            {
                int saveNb = ChooseWork();
                Model.WorkList[saveNb - 1] = null;
                Model.WorkList[saveNb - 1] = new Work("", "", "", WorkType.undefined);
                Model.SaveDataFile();
                Console.WriteLine("Save deleted with success");
                Vue.Start();
            }
            catch (Exception)
            {
                Console.WriteLine("Input not valid");
                Vue.Start();
            }

        }



        public static void ExecuteOne()
        {
            int saveNb = ChooseWork();
            CreateDirectories(saveNb);
            CopyFiles(saveNb);
            Vue.Start();

        }

        public static void ExecuteAll()
        {
            for(int i = 1; i <= Model.MaxWorksNb; i++)
            {
                if(Model.WorkList[i-1].WorkState != WorkState.undefined)
                {
                    CreateDirectories(i);
                    CopyFiles(i);
                }
            }
            Vue.Start();
        }

        private static void CreateDirectories(int workNb)
        {
            foreach(var dirPath in Directory.GetDirectories(Model.WorkList[workNb-1].SrcPath, "*", SearchOption.AllDirectories))
            {
                Directory.CreateDirectory(dirPath.Replace(Model.WorkList[workNb-1].SrcPath, Model.WorkList[workNb-1].DestPath));
            }
        }

        public static int GetDifferentFilesNb(int workNb)
        {
            int nbFiles = 0;
            foreach (var filePath in Directory.GetFiles(Model.WorkList[workNb - 1].SrcPath, "*.*", SearchOption.AllDirectories))
            {
                if (!File.Exists(filePath.Replace(Model.WorkList[workNb - 1].SrcPath, Model.WorkList[workNb - 1].DestPath)))
                {
                    nbFiles++;
                } else
                {
                    if (File.GetLastWriteTime(filePath) != File.GetLastWriteTime(filePath.Replace(Model.WorkList[workNb - 1].SrcPath, Model.WorkList[workNb - 1].DestPath)))
                    {
                        nbFiles++;
                    }
                }
            }
            return nbFiles;

        }

        public static void GetProgression(int workNb)
        {
            Model.WorkList[workNb - 1].Progression = (double)( 100 - (((double)(Model.WorkList[workNb - 1].NbFilesLeftToDo) / (Model.WorkList[workNb - 1].TotalFilesToCopy)) * 100));
        }


        private static void CopyFiles(int workNb)
        {
            if (Model.WorkList[workNb - 1].Type == WorkType.complete)
            {
                Model.WorkList[workNb - 1].NbFilesLeftToDo = Model.WorkList[workNb - 1].TotalFilesToCopy;
            }
            else
            {
                Model.WorkList[workNb - 1].NbFilesLeftToDo = GetDifferentFilesNb(workNb);
            }
                foreach (var filePath in Directory.GetFiles(Model.WorkList[workNb-1].SrcPath, "*.*", SearchOption.AllDirectories))
            {
                var watch = new System.Diagnostics.Stopwatch();
                watch.Start();
                if(Model.WorkList[workNb-1].Type == WorkType.complete)
                {
                    File.Copy(filePath, filePath.Replace(Model.WorkList[workNb-1].SrcPath, Model.WorkList[workNb-1].DestPath), true);
                    Model.WorkList[workNb-1].NbFilesLeftToDo--;
                }
                else
                {
                    if (!File.Exists(filePath.Replace(Model.WorkList[workNb-1].SrcPath, Model.WorkList[workNb - 1].DestPath)))
                    {
                        File.Copy(filePath, filePath.Replace(Model.WorkList[workNb - 1].SrcPath, Model.WorkList[workNb - 1].DestPath), true);
                        Model.WorkList[workNb-1].NbFilesLeftToDo--;
                    }
                    else
                    {
                        if (File.GetLastWriteTime(filePath) != File.GetLastWriteTime(filePath.Replace(Model.WorkList[workNb-1].SrcPath, Model.WorkList[workNb - 1].DestPath)))
                        {
                            File.Copy(filePath, filePath.Replace(Model.WorkList[workNb - 1].SrcPath, Model.WorkList[workNb - 1].DestPath), true);
                            Model.WorkList[workNb-1].NbFilesLeftToDo--;
                        }

                    }
                }
                Model.WorkList[workNb - 1].WorkState = WorkState.active;
                watch.Stop();
                GetProgression(workNb);
                var fi = new FileInfo(filePath);
                FileTransferTime = watch.ElapsedMilliseconds;
                FileSrcPath = Path.GetFullPath(filePath);
                FileDestPath = Path.GetFullPath(filePath).Replace(Model.WorkList[workNb - 1].SrcPath, Model.WorkList[workNb - 1].DestPath);
                FileSize = fi.Length;
                if(Model.WorkList[workNb - 1].NbFilesLeftToDo != 0)
                {
                    Model.WorkList[workNb - 1].WorkState = WorkState.active;
                }
                else
                {
                    Model.WorkList[workNb - 1].WorkState = WorkState.ended;
                }
                LogClass.WriteLog(workNb);
                LogClass.WriteStateLog(workNb);

            }
            Console.WriteLine("Sauvegarde termin�e.");
        }




        public static string SetWorkName()
        {
            var name = "";
            Console.WriteLine("Enter the work name :");
            while (name == "")
            {
                name = Console.ReadLine()!;
            }
            return name;
        }

        public static string SetWorkSrc()
        {
            Console.WriteLine("Enter the source path :");
            var path = Console.ReadLine()!;
            while (!Directory.Exists(path))
            {
                Console.WriteLine("This path is not valid, please try again :");
                path = Console.ReadLine()!;
            }
            return path;
        }

        public static string SetWorkTarget()
        {
            Console.WriteLine("Enter the target path : ");
            var path = Console.ReadLine()!;
            try
            {
                while ((!Directory.Exists(path)))
                {
                    Directory.CreateDirectory(path);
                }
            }
            catch (Exception e)
            {
                Console.Write("This path is not valid, please try again : ");
                path = Console.ReadLine()!;
            }
            return path;
        }

        public static WorkType SetWorkType()
        {
            Console.WriteLine("Choose a save type : complete or differential (c/d)");
            var type = Console.ReadLine()!;
            WorkType t = WorkType.undefined;
            while (type != "c" && type != "d")
            {
                Console.WriteLine("Wrong input, please enter again :");
                type = Console.ReadLine()!;
            }
            if(type == "c")
            {
                t = WorkType.complete;
            }
            else
            {
                t = WorkType.differential;
            }
            return t;
        }

        public static int FilesToCopy(DirectoryInfo _directory_srcPath)
        {
            int TotaFilesNb = 0;
            foreach (FileInfo ffinfo in _directory_srcPath.GetFiles())
            {
                TotaFilesNb++;
            }
            foreach (DirectoryInfo subDir in _directory_srcPath.GetDirectories())
            {
                TotaFilesNb += FilesToCopy(subDir);
            }

            return TotaFilesNb;
        }

        public static long DirectorySize(DirectoryInfo _directory_srcPath)
        {
            long TotalDirSize= 0 ;
            foreach (FileInfo finfo in _directory_srcPath.GetFiles())
            {
                TotalDirSize += finfo.Length;
            }
            foreach (DirectoryInfo subDir in _directory_srcPath.GetDirectories())
            {
                TotalDirSize += DirectorySize(subDir);
            }

            return TotalDirSize;
        }
    }
}